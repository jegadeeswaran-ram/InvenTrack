import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../services/auth_service.dart';
import '../../services/api_service.dart';

class StockScreen extends StatefulWidget {
  const StockScreen({super.key});

  @override
  State<StockScreen> createState() => _StockScreenState();
}

class _StockScreenState extends State<StockScreen> {
  List<dynamic> _stock = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final token = context.read<AuthService>().token;
    try {
      final data = await ApiService.get('/reports/stock', token: token);
      setState(() { _stock = data; _loading = false; });
    } catch (_) { setState(() => _loading = false); }
  }

  Widget _badge(double inHand) {
    if (inHand <= 0) return _chip('Out of Stock', const Color(0xFFFFEBEE), const Color(0xFFB71C1C));
    if (inHand <= 20) return _chip('Low', const Color(0xFFFFF3E0), const Color(0xFFE65100));
    return _chip('Healthy', const Color(0xFFE8F5E9), const Color(0xFF2E7D32));
  }

  Widget _chip(String text, Color bg, Color fg) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12)),
    child: Text(text, style: TextStyle(color: fg, fontSize: 12, fontWeight: FontWeight.w700)),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Current Stock')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: _stock.map((p) {
                    final inHand = (p['inHand'] as num).toDouble();
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(children: [
                                  Text(p['emoji'] ?? '🍦', style: const TextStyle(fontSize: 32)),
                                  const SizedBox(width: 10),
                                  Text(p['productName'], style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                                ]),
                                _badge(inHand),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text('In Hand', style: const TextStyle(color: Color(0xFF607D8B), fontSize: 12)),
                                Text(inHand.toStringAsFixed(0), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: Color(0xFF0097A7))),
                              ],
                            ),
                            const Divider(height: 20),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                _stat('Purchased', '${(p['totalPurchased'] as num).toStringAsFixed(0)}'),
                                _stat('Sold', '${(p['totalSold'] as num).toStringAsFixed(0)}'),
                                _stat('Avg Buy', '₹${(p['avgCostPerUnit'] as num).toStringAsFixed(2)}'),
                                _stat('Avg Sell', '₹${(p['avgSellPerUnit'] as num).toStringAsFixed(2)}'),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
    );
  }

  Widget _stat(String label, String value) => Column(
    children: [
      Text(value, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
      Text(label, style: const TextStyle(color: Color(0xFF607D8B), fontSize: 10)),
    ],
  );
}
