import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../services/auth_service.dart';
import '../../services/api_service.dart';
import '../login_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<dynamic> _stock = [];
  Map<String, dynamic>? _daily;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final token = context.read<AuthService>().token;
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    try {
      final results = await Future.wait([
        ApiService.get('/reports/stock', token: token),
        ApiService.get('/reports/daily?date=$today', token: token),
      ]);
      setState(() {
        _stock = results[0];
        _daily = results[1];
        _loading = false;
      });
    } catch (_) { setState(() => _loading = false); }
  }

  Widget _kpiCard(String label, String value, {Color? valueColor}) => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontSize: 11, color: Color(0xFF607D8B), fontWeight: FontWeight.w600, letterSpacing: 0.5)),
        const SizedBox(height: 6),
        Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: valueColor ?? const Color(0xFF0097A7))),
      ]),
    ),
  );

  Widget _stockBadge(double inHand) {
    if (inHand <= 0) return _badge('Out of Stock', const Color(0xFFFFEBEE), const Color(0xFFB71C1C));
    if (inHand <= 20) return _badge('Low', const Color(0xFFFFF3E0), const Color(0xFFE65100));
    return _badge('Healthy', const Color(0xFFE8F5E9), const Color(0xFF2E7D32));
  }

  Widget _badge(String text, Color bg, Color fg) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12)),
    child: Text(text, style: TextStyle(fontSize: 11, color: fg, fontWeight: FontWeight.w600)),
  );

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthService>().user;
    final summary = _daily?['summary'] ?? {};

    return Scaffold(
      appBar: AppBar(
        title: const Text('🍦 Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await context.read<AuthService>().logout();
              if (!context.mounted) return;
              Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen()));
            },
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Hello, ${user?.name ?? 'Admin'} 👋',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                    Text(DateFormat('dd MMM yyyy').format(DateTime.now()),
                        style: const TextStyle(color: Color(0xFF607D8B))),
                    const SizedBox(height: 16),

                    // KPI grid
                    GridView.count(
                      crossAxisCount: 2,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                      childAspectRatio: 1.6,
                      children: [
                        _kpiCard('Stock in Hand', '${_stock.fold<double>(0, (s, p) => s + (p['inHand'] as num).toDouble()).toStringAsFixed(0)} units'),
                        _kpiCard('Today Purchased', '${(summary['unitsPurchased'] ?? 0).toStringAsFixed(0)} units'),
                        _kpiCard('Today Sales', '${(summary['unitsSold'] ?? 0).toStringAsFixed(0)} units'),
                        _kpiCard('Today Profit', '₹${((summary['totalProfit'] ?? 0) as num).toStringAsFixed(2)}', valueColor: const Color(0xFF43A047)),
                      ],
                    ),
                    const SizedBox(height: 20),

                    const Text('Stock Summary', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    const SizedBox(height: 8),
                    ..._stock.map((p) => Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: ListTile(
                        leading: Text(p['emoji'] ?? '🍦', style: const TextStyle(fontSize: 28)),
                        title: Text(p['productName'], style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Text('In hand: ${(p['inHand'] as num).toStringAsFixed(0)} units'),
                        trailing: _stockBadge((p['inHand'] as num).toDouble()),
                      ),
                    )),
                  ],
                ),
              ),
            ),
    );
  }
}
