import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../services/auth_service.dart';
import '../../services/api_service.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() { _tab.dispose(); super.dispose(); }

  String? get _token => context.read<AuthService>().token;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reports'),
        bottom: TabBar(
          controller: _tab,
          labelColor: Colors.white,
          unselectedLabelColor: const Color(0xFFB2EBF2),
          indicatorColor: Colors.white,
          tabs: const [Tab(text: 'Daily'), Tab(text: 'Monthly'), Tab(text: 'Yearly')],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          _DailyTab(token: _token),
          _MonthlyTab(token: _token),
          _YearlyTab(token: _token),
        ],
      ),
    );
  }
}

class _DailyTab extends StatefulWidget {
  final String? token;
  const _DailyTab({required this.token});
  @override State<_DailyTab> createState() => _DailyTabState();
}

class _DailyTabState extends State<_DailyTab> {
  DateTime _date = DateTime.now();
  Map<String, dynamic>? _data;
  bool _loading = false;

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final d = DateFormat('yyyy-MM-dd').format(_date);
      final r = await ApiService.get('/reports/daily?date=$d', token: widget.token);
      setState(() => _data = r);
    } catch (_) {} finally { setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    final summary = _data?['summary'] ?? {};
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(children: [
            Expanded(child: InkWell(
              onTap: () async {
                final d = await showDatePicker(context: context, initialDate: _date, firstDate: DateTime(2020), lastDate: DateTime.now());
                if (d != null) setState(() => _date = d);
              },
              child: InputDecorator(
                decoration: const InputDecoration(labelText: 'Date', prefixIcon: Icon(Icons.calendar_today_outlined)),
                child: Text(DateFormat('dd MMM yyyy').format(_date)),
              ),
            )),
            const SizedBox(width: 10),
            ElevatedButton(
              onPressed: _loading ? null : _load,
              style: ElevatedButton.styleFrom(minimumSize: const Size(80, 52)),
              child: _loading ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) : const Text('Load'),
            ),
          ]),
          if (_data != null) ...[
            const SizedBox(height: 16),
            _kpiRow([
              ('Units Purchased', '${(summary['unitsPurchased'] ?? 0).toStringAsFixed(0)}'),
              ('Units Sold', '${(summary['unitsSold'] ?? 0).toStringAsFixed(0)}'),
            ]),
            const SizedBox(height: 8),
            _kpiRow([
              ('Purchase Cost', '₹${((summary['totalPurchaseCost'] ?? 0) as num).toStringAsFixed(2)}'),
              ('Revenue', '₹${((summary['totalRevenue'] ?? 0) as num).toStringAsFixed(2)}'),
              ('Profit', '₹${((summary['totalProfit'] ?? 0) as num).toStringAsFixed(2)}'),
            ]),
            const SizedBox(height: 16),
            _tableCard('Purchases', ['Product', 'Qty', 'Cost'], (_data!['purchases'] as List).map((p) => <String>[p['productName'].toString(), '${p['quantity']}', '₹${(p['totalCost'] as num).toStringAsFixed(2)}']).toList()),
            const SizedBox(height: 12),
            _tableCard('Sales', ['Product', 'Qty', 'Revenue', 'Profit'], (_data!['sales'] as List).map((s) => <String>[s['productName'].toString(), '${s['quantity']}', '₹${(s['totalRevenue'] as num).toStringAsFixed(2)}', '₹${(s['profit'] as num).toStringAsFixed(2)}']).toList()),
          ],
        ],
      ),
    );
  }
}

class _MonthlyTab extends StatefulWidget {
  final String? token;
  const _MonthlyTab({required this.token});
  @override State<_MonthlyTab> createState() => _MonthlyTabState();
}

class _MonthlyTabState extends State<_MonthlyTab> {
  String _month = DateFormat('yyyy-MM').format(DateTime.now());
  Map<String, dynamic>? _data;
  bool _loading = false;

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final r = await ApiService.get('/reports/monthly?month=$_month', token: widget.token);
      setState(() => _data = r);
    } catch (_) {} finally { setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(children: [
            Expanded(child: TextFormField(
              initialValue: _month,
              decoration: const InputDecoration(labelText: 'Month (YYYY-MM)'),
              onChanged: (v) => _month = v,
            )),
            const SizedBox(width: 10),
            ElevatedButton(
              onPressed: _loading ? null : _load,
              style: ElevatedButton.styleFrom(minimumSize: const Size(80, 52)),
              child: _loading ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) : const Text('Load'),
            ),
          ]),
          if (_data != null) ...[
            const SizedBox(height: 16),
            _tableCard('Day-wise', ['Date', 'Cost', 'Revenue', 'Profit'],
              (_data!['dayWise'] as List).map((d) => <String>[d['date'].toString(), '₹${(d['purchaseCost'] as num).toStringAsFixed(2)}', '₹${(d['revenue'] as num).toStringAsFixed(2)}', '₹${(d['profit'] as num).toStringAsFixed(2)}']).toList()),
            const SizedBox(height: 12),
            _tableCard('Product-wise', ['Product', 'Units Sold', 'Profit'],
              (_data!['productWise'] as List).map((p) => <String>[p['productName'].toString(), '${p['unitsSold']}', '₹${(p['totalProfit'] as num).toStringAsFixed(2)}']).toList()),
          ],
        ],
      ),
    );
  }
}

class _YearlyTab extends StatefulWidget {
  final String? token;
  const _YearlyTab({required this.token});
  @override State<_YearlyTab> createState() => _YearlyTabState();
}

class _YearlyTabState extends State<_YearlyTab> {
  String _year = DateTime.now().year.toString();
  Map<String, dynamic>? _data;
  bool _loading = false;

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final r = await ApiService.get('/reports/yearly?year=$_year', token: widget.token);
      setState(() => _data = r);
    } catch (_) {} finally { setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(children: [
            Expanded(child: DropdownButtonFormField<String>(
              value: _year,
              decoration: const InputDecoration(labelText: 'Year'),
              items: ['2024', '2025', '2026', '2027'].map((y) => DropdownMenuItem(value: y, child: Text(y))).toList(),
              onChanged: (v) => setState(() => _year = v!),
            )),
            const SizedBox(width: 10),
            ElevatedButton(
              onPressed: _loading ? null : _load,
              style: ElevatedButton.styleFrom(minimumSize: const Size(80, 52)),
              child: _loading ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) : const Text('Load'),
            ),
          ]),
          if (_data != null) ...[
            const SizedBox(height: 16),
            _tableCard('${_data!['year']} Month-wise', ['Month', 'Cost', 'Revenue', 'Profit'],
              (_data!['months'] as List).map((m) => <String>[m['label'].toString(), '₹${(m['purchaseCost'] as num).toStringAsFixed(2)}', '₹${(m['revenue'] as num).toStringAsFixed(2)}', '₹${(m['profit'] as num).toStringAsFixed(2)}']).toList()),
          ],
        ],
      ),
    );
  }
}

// Shared helpers
Widget _kpiRow(List<(String, String)> items) => Row(
  children: items.map((item) => Expanded(child: Card(
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(item.$1, style: const TextStyle(fontSize: 11, color: Color(0xFF607D8B), fontWeight: FontWeight.w600)),
        const SizedBox(height: 4),
        Text(item.$2, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Color(0xFF0097A7))),
      ]),
    ),
  ))).toList(),
);

Widget _tableCard(String title, List<String> headers, List<List<String>> rows) => Card(
  child: Padding(
    padding: const EdgeInsets.all(12),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            headingRowHeight: 36,
            dataRowMinHeight: 36,
            dataRowMaxHeight: 40,
            columnSpacing: 16,
            columns: headers.map((h) => DataColumn(label: Text(h, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)))).toList(),
            rows: rows.isEmpty
                ? [DataRow(cells: [DataCell(Text('No data', style: const TextStyle(color: Color(0xFF607D8B)))), ...List.generate(headers.length - 1, (_) => const DataCell(Text('')))])]
                : rows.map((r) => DataRow(cells: r.map((c) => DataCell(Text(c, style: const TextStyle(fontSize: 12)))).toList())).toList(),
          ),
        ),
      ],
    ),
  ),
);
