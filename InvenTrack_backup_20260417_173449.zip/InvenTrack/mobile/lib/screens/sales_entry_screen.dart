import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
import '../services/api_service.dart';
import 'login_screen.dart';

class SalesEntryScreen extends StatefulWidget {
  const SalesEntryScreen({super.key});

  @override
  State<SalesEntryScreen> createState() => _SalesEntryScreenState();
}

class _SalesEntryScreenState extends State<SalesEntryScreen> {
  final _formKey = GlobalKey<FormState>();
  final _qtyCtrl = TextEditingController();
  final _priceCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();

  List<dynamic> _products = [];
  List<dynamic> _todaySales = [];
  dynamic _selectedProduct;
  DateTime _date = DateTime.now();
  bool _submitting = false;
  bool _loadingProducts = true;
  String? _msg;
  bool _msgSuccess = false;

  @override
  void initState() {
    super.initState();
    _loadProducts();
    _loadTodaySales();
  }

  Future<void> _loadProducts() async {
    final token = context.read<AuthService>().token;
    try {
      final data = await ApiService.get('/products', token: token);
      setState(() { _products = data; _loadingProducts = false; });
    } catch (_) { setState(() { _loadingProducts = false; }); }
  }

  Future<void> _loadTodaySales() async {
    final token = context.read<AuthService>().token;
    final dateStr = DateFormat('yyyy-MM-dd').format(DateTime.now());
    try {
      final data = await ApiService.get('/sales?date=$dateStr', token: token);
      setState(() { _todaySales = data; });
    } catch (_) {}
  }

  double get _totalRevenue {
    final qty = double.tryParse(_qtyCtrl.text) ?? 0;
    final price = double.tryParse(_priceCtrl.text) ?? 0;
    return qty * price;
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedProduct == null) {
      setState(() { _msg = 'Please select a product'; _msgSuccess = false; });
      return;
    }
    setState(() { _submitting = true; _msg = null; });
    final token = context.read<AuthService>().token;
    try {
      await ApiService.post('/sales', {
        'date': DateFormat('yyyy-MM-dd').format(_date),
        'productId': _selectedProduct['id'],
        'quantity': double.parse(_qtyCtrl.text),
        'pricePerUnit': double.parse(_priceCtrl.text),
        'notes': _notesCtrl.text.isEmpty ? null : _notesCtrl.text,
      }, token: token);
      setState(() {
        _msg = 'Saved successfully!';
        _msgSuccess = true;
        _qtyCtrl.clear();
        _priceCtrl.clear();
        _notesCtrl.clear();
        _selectedProduct = null;
      });
      _loadTodaySales();
    } catch (e) {
      setState(() { _msg = e.toString(); _msgSuccess = false; });
    } finally {
      setState(() { _submitting = false; });
    }
  }

  Future<void> _logout() async {
    await context.read<AuthService>().logout();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthService>().user;

    return Scaffold(
      appBar: AppBar(
        title: const Text('🍦 Kulfi ICE'),
        actions: [
          IconButton(icon: const Icon(Icons.logout), tooltip: 'Logout', onPressed: _logout),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Greeting
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF0097A7),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Hello, ${user?.name ?? 'there'}! 👋',
                        style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    const Text('Enter today\'s sales below',
                        style: TextStyle(color: Color(0xFFB2EBF2), fontSize: 13)),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Form
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('New Sale Entry', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                        const SizedBox(height: 16),

                        // Date
                        InkWell(
                          onTap: () async {
                            final d = await showDatePicker(
                              context: context,
                              initialDate: _date,
                              firstDate: DateTime(2020),
                              lastDate: DateTime.now(),
                            );
                            if (d != null) setState(() => _date = d);
                          },
                          child: InputDecorator(
                            decoration: const InputDecoration(
                              labelText: 'Date',
                              prefixIcon: Icon(Icons.calendar_today_outlined),
                            ),
                            child: Text(DateFormat('dd MMM yyyy').format(_date)),
                          ),
                        ),
                        const SizedBox(height: 12),

                        // Product picker
                        _loadingProducts
                            ? const Center(child: CircularProgressIndicator())
                            : DropdownButtonFormField<dynamic>(
                                initialValue: _selectedProduct,
                                decoration: const InputDecoration(
                                  labelText: 'Product',
                                  prefixIcon: Icon(Icons.icecream_outlined),
                                ),
                                hint: const Text('Select product…'),
                                items: _products.map((p) => DropdownMenuItem(
                                      value: p,
                                      child: Text('${p['emoji']} ${p['name']}'),
                                    )).toList(),
                                onChanged: (v) {
                                  setState(() {
                                    _selectedProduct = v;
                                    if (v != null && _priceCtrl.text.isEmpty) {
                                      _priceCtrl.text = v['sellingPrice']?.toString() ?? '';
                                    } else if (v != null) {
                                      _priceCtrl.text = v['sellingPrice']?.toString() ?? '';
                                    }
                                  });
                                },
                              ),
                        const SizedBox(height: 12),

                        // Quantity
                        TextFormField(
                          controller: _qtyCtrl,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
                          decoration: const InputDecoration(labelText: 'Units Sold', prefixIcon: Icon(Icons.numbers)),
                          validator: (v) => (v == null || v.isEmpty) ? 'Required' : null,
                          onChanged: (_) => setState(() {}),
                        ),
                        const SizedBox(height: 12),

                        // Price per unit
                        TextFormField(
                          controller: _priceCtrl,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
                          decoration: const InputDecoration(labelText: 'Price per Unit (₹)', prefixIcon: Icon(Icons.currency_rupee)),
                          validator: (v) => (v == null || v.isEmpty) ? 'Required' : null,
                          onChanged: (_) => setState(() {}),
                        ),
                        const SizedBox(height: 12),

                        // Total revenue display
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFFE0F7FA),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Total Revenue', style: TextStyle(fontWeight: FontWeight.w600)),
                              Text(
                                '₹ ${_totalRevenue.toStringAsFixed(2)}',
                                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Color(0xFF0097A7)),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),

                        // Notes
                        TextFormField(
                          controller: _notesCtrl,
                          decoration: const InputDecoration(labelText: 'Notes (optional)', prefixIcon: Icon(Icons.note_outlined)),
                          maxLines: 2,
                        ),

                        if (_msg != null) ...[
                          const SizedBox(height: 10),
                          Text(
                            _msg!,
                            style: TextStyle(color: _msgSuccess ? const Color(0xFF43A047) : const Color(0xFFE53935), fontWeight: FontWeight.w500),
                          ),
                        ],
                        const SizedBox(height: 16),

                        ElevatedButton(
                          onPressed: _submitting ? null : _submit,
                          child: _submitting
                              ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                              : const Text('Save Sale'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // Today's entries
              const Text("Today's Entries", style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              const SizedBox(height: 12),
              if (_todaySales.isEmpty)
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Center(child: Text('No sales recorded today', style: TextStyle(color: Color(0xFF607D8B)))),
                  ),
                )
              else
                ..._todaySales.map((s) => Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    leading: Text(s['product']?['emoji'] ?? '🍦', style: const TextStyle(fontSize: 28)),
                    title: Text(s['product']?['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text('${s['quantity']} units × ₹${s['pricePerUnit']}'),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text('₹${(s['totalRevenue'] as num).toStringAsFixed(2)}',
                            style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF0097A7))),
                        Text(DateFormat('dd MMM').format(DateTime.parse(s['date'])),
                            style: const TextStyle(fontSize: 11, color: Color(0xFF607D8B))),
                      ],
                    ),
                  ),
                )),
            ],
          ),
        ),
      ),
    );
  }
}
