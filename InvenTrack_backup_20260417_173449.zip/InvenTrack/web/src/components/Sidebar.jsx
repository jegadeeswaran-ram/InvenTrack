import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const nav = [
  { path: '/', label: 'Dashboard', icon: '📊' },
  { path: '/purchase', label: 'Purchase Entry', icon: '🛒' },
  { path: '/sales', label: 'Sales Entry', icon: '💰' },
  { path: '/stock', label: 'Current Stock', icon: '📦' },
  { path: '/reports', label: 'Reports', icon: '📈' },
  { path: '/products', label: 'Products', icon: '🏷️' },
  { path: '/settings', label: 'Settings', icon: '⚙️' },
];

export default function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <aside style={{
      width: 220, minHeight: '100vh', background: 'var(--sidebar-bg)',
      display: 'flex', flexDirection: 'column', position: 'fixed', left: 0, top: 0, bottom: 0,
    }}>
      {/* Logo */}
      <div style={{ padding: '24px 20px 20px', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
        <div style={{ fontSize: 20, fontWeight: 800, color: '#fff' }}>🍦 Kulfi ICE</div>
        <div style={{ fontSize: 11, color: 'var(--sidebar-text)', marginTop: 2, letterSpacing: 1 }}>INVENTRACK</div>
      </div>

      {/* Nav links */}
      <nav style={{ flex: 1, padding: '12px 0' }}>
        {nav.map(({ path, label, icon }) => (
          <NavLink
            key={path}
            to={path}
            end={path === '/'}
            style={({ isActive }) => ({
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '10px 20px', fontSize: 14, fontWeight: 500,
              color: isActive ? 'var(--sidebar-active)' : 'var(--sidebar-text)',
              background: isActive ? 'rgba(255,255,255,0.12)' : 'transparent',
              borderLeft: isActive ? '3px solid #fff' : '3px solid transparent',
              transition: 'all 0.15s',
            })}
          >
            <span>{icon}</span>
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>

      {/* User info + logout */}
      <div style={{ padding: '16px 20px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
        <div style={{ fontSize: 13, color: '#fff', fontWeight: 600 }}>{user?.name}</div>
        <div style={{ fontSize: 11, color: 'var(--sidebar-text)', marginTop: 2 }}>
          <span className={`badge badge-${user?.role?.toLowerCase()}`}>{user?.role}</span>
        </div>
        <button
          onClick={handleLogout}
          style={{ marginTop: 12, width: '100%', background: 'rgba(255,255,255,0.1)', color: '#fff', padding: '7px 12px', borderRadius: 6, fontSize: 13 }}
        >
          Logout
        </button>
      </div>
    </aside>
  );
}
