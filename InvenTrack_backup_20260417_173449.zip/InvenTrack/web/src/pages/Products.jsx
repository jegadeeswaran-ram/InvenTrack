import { useState, useEffect } from 'react';
import api from '../api/axios';

const EMOJIS = ['🍦', '🍡', '🪔', '🍨', '🫙', '👑', '🥤', '🧁', '🍧', '🍰'];

function ProductImage({ imageUrl, emoji, size = 80 }) {
  const [err, setErr] = useState(false);
  if (imageUrl && !err) {
    return (
      <img
        src={imageUrl}
        alt=""
        onError={() => setErr(true)}
        style={{ width: size, height: size, objectFit: 'contain', borderRadius: 8 }}
      />
    );
  }
  return <div style={{ fontSize: size * 0.5, lineHeight: 1, textAlign: 'center', width: size, height: size, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{emoji}</div>;
}

export default function Products() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [form, setForm] = useState({ name: '', emoji: '🍦', sellingPrice: '', imageUrl: '' });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const fetchProducts = () => {
    api.get('/products').then(r => { setProducts(r.data); setLoading(false); });
  };

  useEffect(() => { fetchProducts(); }, []);

  const openAdd = () => {
    setEditProduct(null);
    setForm({ name: '', emoji: '🍦', sellingPrice: '', imageUrl: '' });
    setError('');
    setShowForm(true);
  };

  const openEdit = (p) => {
    setEditProduct(p);
    setForm({ name: p.name, emoji: p.emoji, sellingPrice: String(p.sellingPrice), imageUrl: p.imageUrl || '' });
    setError('');
    setShowForm(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return setError('Product name is required');
    if (!form.sellingPrice || isNaN(form.sellingPrice) || Number(form.sellingPrice) <= 0)
      return setError('Enter a valid selling price');

    setSaving(true);
    setError('');
    try {
      const payload = { ...form, sellingPrice: parseFloat(form.sellingPrice), imageUrl: form.imageUrl || null };
      if (editProduct) {
        await api.put(`/products/${editProduct.id}`, payload);
      } else {
        await api.post('/products', payload);
      }
      setShowForm(false);
      fetchProducts();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save product');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Deactivate this product?')) return;
    await api.delete(`/products/${id}`);
    fetchProducts();
  };

  if (loading) return <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>Loading…</div>;

  return (
    <div>
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1>Products</h1>
          <p>Manage your kulfi product catalogue and selling prices</p>
        </div>
        <button className="btn-primary" onClick={openAdd} style={{ marginTop: 4 }}>+ Add Product</button>
      </div>

      {/* Modal */}
      {showForm && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000,
        }}>
          <div className="card" style={{ width: 460, maxWidth: '90vw', maxHeight: '90vh', overflowY: 'auto' }}>
            <h2 style={{ marginBottom: 20, fontSize: 18 }}>{editProduct ? 'Edit Product' : 'Add Product'}</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Product Name</label>
                <input
                  className="form-input"
                  placeholder="e.g. Amul Punjabi Kulfi"
                  value={form.name}
                  onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                />
              </div>

              <div className="form-group">
                <label>Product Image URL <span style={{ color: 'var(--text-muted)', fontWeight: 400 }}>(optional)</span></label>
                <input
                  className="form-input"
                  placeholder="https://example.com/kulfi.png"
                  value={form.imageUrl}
                  onChange={e => setForm(f => ({ ...f, imageUrl: e.target.value }))}
                />
                {form.imageUrl && (
                  <div style={{ marginTop: 8, display: 'flex', alignItems: 'center', gap: 10 }}>
                    <ProductImage imageUrl={form.imageUrl} emoji={form.emoji} size={64} />
                    <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Preview</span>
                  </div>
                )}
              </div>

              <div className="form-group">
                <label>Fallback Emoji</label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 6 }}>
                  {EMOJIS.map(em => (
                    <button
                      type="button"
                      key={em}
                      onClick={() => setForm(f => ({ ...f, emoji: em }))}
                      style={{
                        fontSize: 22, padding: '4px 8px', borderRadius: 8, cursor: 'pointer',
                        border: form.emoji === em ? '2px solid var(--primary)' : '2px solid transparent',
                        background: form.emoji === em ? 'var(--primary-light)' : 'var(--bg)',
                      }}
                    >{em}</button>
                  ))}
                </div>
              </div>

              <div className="form-group">
                <label>Selling Price (₹)</label>
                <input
                  className="form-input"
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="e.g. 25"
                  value={form.sellingPrice}
                  onChange={e => setForm(f => ({ ...f, sellingPrice: e.target.value }))}
                />
              </div>

              {error && <div style={{ color: '#e53935', fontSize: 13, marginBottom: 12 }}>{error}</div>}

              <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
                <button type="button" className="btn-secondary" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" className="btn-primary" disabled={saving}>
                  {saving ? 'Saving…' : editProduct ? 'Update' : 'Add Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Product grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 16 }}>
        {products.map(p => (
          <div key={p.id} className="card" style={{ borderTop: '3px solid var(--primary)' }}>
            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 8 }}>
              <ProductImage imageUrl={p.imageUrl} emoji={p.emoji} size={90} />
            </div>
            <div style={{ fontWeight: 700, fontSize: 15, marginTop: 4 }}>{p.name}</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--primary)', marginTop: 8 }}>
              ₹{p.sellingPrice}
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>Selling Price</div>
            <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
              <button className="btn-secondary" style={{ flex: 1, fontSize: 12 }} onClick={() => openEdit(p)}>Edit</button>
              <button
                style={{ flex: 1, fontSize: 12, padding: '6px 10px', borderRadius: 6, border: '1px solid #e53935', color: '#e53935', background: 'transparent', cursor: 'pointer' }}
                onClick={() => handleDelete(p.id)}
              >Remove</button>
            </div>
          </div>
        ))}
      </div>

      {products.length === 0 && (
        <div className="card" style={{ textAlign: 'center', padding: 40, color: 'var(--text-muted)' }}>
          No products yet. Click "+ Add Product" to get started.
        </div>
      )}
    </div>
  );
}
