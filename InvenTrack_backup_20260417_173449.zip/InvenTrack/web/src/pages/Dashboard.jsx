import { useState, useEffect } from 'react';
import api from '../api/axios';

function today() {
  return new Date().toISOString().split('T')[0];
}

function fmt(n) {
  return typeof n === 'number' ? n.toFixed(2) : '0.00';
}

function StockBadge({ inHand }) {
  if (inHand <= 0) return <span className="badge badge-out">Out of Stock</span>;
  if (inHand <= 20) return <span className="badge badge-low">Low</span>;
  return <span className="badge badge-healthy">Healthy</span>;
}

export default function Dashboard() {
  const [stock, setStock] = useState([]);
  const [daily, setDaily] = useState(null);
  const [recentPurchases, setRecentPurchases] = useState([]);
  const [recentSales, setRecentSales] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [stockRes, dailyRes, purchasesRes, salesRes] = await Promise.all([
          api.get('/reports/stock'),
          api.get(`/reports/daily?date=${today()}`),
          api.get('/purchases'),
          api.get('/sales'),
        ]);
        setStock(stockRes.data);
        setDaily(dailyRes.data);
        setRecentPurchases(purchasesRes.data.slice(0, 5));
        setRecentSales(salesRes.data.slice(0, 5));
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, []);

  const totalInHand = stock.reduce((s, p) => s + p.inHand, 0);

  if (loading) return <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>Loading…</div>;

  return (
    <div>
      <div className="page-header">
        <h1>Dashboard</h1>
        <p>Today: {today()}</p>
      </div>

      {/* KPI Cards */}
      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="label">Total Stock in Hand</div>
          <div className="value">{totalInHand.toFixed(0)}</div>
          <div className="sub">units across all products</div>
        </div>
        <div className="kpi-card">
          <div className="label">Today Purchased</div>
          <div className="value">{daily?.summary?.unitsPurchased?.toFixed(0) ?? 0}</div>
          <div className="sub">units · ₹{fmt(daily?.summary?.totalPurchaseCost)}</div>
        </div>
        <div className="kpi-card">
          <div className="label">Today Sales</div>
          <div className="value">{daily?.summary?.unitsSold?.toFixed(0) ?? 0}</div>
          <div className="sub">units · ₹{fmt(daily?.summary?.totalRevenue)}</div>
        </div>
        <div className="kpi-card">
          <div className="label">Today Profit</div>
          <div className="value" style={{ color: 'var(--success)' }}>₹{fmt(daily?.summary?.totalProfit)}</div>
          <div className="sub">net profit today</div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
        {/* Stock Summary */}
        <div className="card">
          <div className="section-title">Stock Summary</div>
          {stock.length === 0 ? (
            <p className="empty-state">No products found</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Product</th>
                  <th>In Hand</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {stock.map((p) => (
                  <tr key={p.productId}>
                    <td>{p.emoji} {p.productName}</td>
                    <td><strong>{p.inHand.toFixed(0)}</strong></td>
                    <td><StockBadge inHand={p.inHand} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Recent Activity */}
        <div className="card">
          <div className="section-title">Recent Activity</div>
          {recentPurchases.length === 0 && recentSales.length === 0 ? (
            <p className="empty-state">No recent entries</p>
          ) : (
            <div>
              {[...recentPurchases.map(p => ({ ...p, type: 'purchase' })),
                ...recentSales.map(s => ({ ...s, type: 'sale' }))]
                .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
                .slice(0, 8)
                .map((entry) => (
                  <div key={`${entry.type}-${entry.id}`} style={{
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    padding: '8px 0', borderBottom: '1px solid var(--border)',
                  }}>
                    <div>
                      <span style={{ marginRight: 6 }}>
                        {entry.type === 'purchase' ? '🛒' : '💰'}
                      </span>
                      <span style={{ fontWeight: 500 }}>{entry.product?.name}</span>
                      <span style={{ color: 'var(--text-muted)', marginLeft: 6, fontSize: 12 }}>
                        {entry.type === 'purchase' ? `qty ${entry.quantity}` : `sold ${entry.quantity}`}
                      </span>
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                      {new Date(entry.date).toLocaleDateString('en-IN')}
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
